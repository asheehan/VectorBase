var cvConstantsJson = {
"cvs" : [ {"id" : "11", "prefix" : "GO:", "full" : "GO:Biological Process"},
          {"id" : "12", "prefix" : "GO:", "full" : "GO:Molecular Function"},
          {"id" : "13", "prefix" : "GO:", "full" : "GO:Cellular Component"},
          {"id" : "21", "prefix" : "TADS:", "full" : "TADS:Tick Anatomy"},
          {"id" : "22", "prefix" : "TGMA:", "full" : "TGMA:CARO Mosquito Anatomy"},
          {"id" : "23", "prefix" : "MIRO:", "full" : "MIRO:Mosquito Insecticide Resistance Ontology"},
          {"id" : "25", "prefix" : "IDOMAL:", "full" : "IDOMAL:Infectious Disease Ontology"}
        ]
};

