<?
class OntologyConstants {

    const ONTOLOGIES = array(
    array(11, "GO", "Biological Process"),
    array(12, "GO", "Molecular Function"),
    array(13, "GO", "Cellular Component"),
    array(21, "TADS", "Tick Anatomy"),
    array(22, "TGMA", "CARO Mosquito Anatomy"),
    array(23, "MIRO", "Mosquito Insecticide Resistance Ontology")
);
    
    
}

?>
